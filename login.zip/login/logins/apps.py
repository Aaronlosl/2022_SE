from django.apps import AppConfig


class LoginsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'logins'
