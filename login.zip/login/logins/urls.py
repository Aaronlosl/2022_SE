from . import views
from django.urls import path, include


app_name = 'logins'
urlpatterns = [
    path('', views.index, name='index'),
    path('results/', views.results, name='results'),
    path('signup/', views.signup, name='signup'),
    path('save/', views.savee, name='save'),
    path('wrong/', views.wrong, name='wrong'),
]