from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse,  HttpResponseRedirect
from django.http import Http404
from .models import Question, Choice, User
from django.template import loader
from django.urls import reverse

def index(request):
    question = get_object_or_404(Question, pk=1)
    return render(request, 'logins/index.html', {'question': question})

def results(request):
    question = get_object_or_404(Question, pk=1)
    user = request.POST['user    ']
    password = request.POST['password']
    for p in User.objects.all() :
        if p.username == user and p.password == password:
            return HttpResponse("success!")
    return HttpResponseRedirect(reverse('logins:wrong'))
    
def signup(request):
    question = get_object_or_404(Question, pk=1)
    return render(request, 'logins/signup.html', {'question': question})

def savee(request):
    user = request.POST['user    ']
    password = request.POST['password']
    u = User(username=user, password=password)
    u.save()
    return HttpResponseRedirect(reverse('logins:index'))

def wrong(request):
    return render(request, 'logins/wrong.html')


    


