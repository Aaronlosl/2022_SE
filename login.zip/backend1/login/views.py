from audioop import reverse
import imp
from django.shortcuts import render,get_object_or_404
from django.http import HttpRequest, HttpResponse,HttpResponseRedirect
from .models import User
from django.urls import reverse
# Create your views here.
def index(request):
    if request.method=='GET':
        return render(request,'login/index.html')
    try:
        user=User.objects.get(name=request.POST['name'])
    except (KeyError ,User.DoesNotExist):
        return render(request,'login/index.html',{
            'err_text':'name not found',
        })
    
    if user.password == request.POST['password']:
        return HttpResponseRedirect(reverse('login:results',args=(user.name,)))
        return render(request,'login/hello.html',{
        'name':user.name,
        'all':User.objects.all()
        })
        return HttpResponseRedirect(reverse('login:results',args=(user.name,)))
    else:
        return render(request,'login/index.html',{
            'err_text':'password error',
        })

def detail(request,user_name,cur_name):
    cur=User.objects.filter(name=cur_name)
    if request.method=='POST':
        print(request.POST['p'])
        if request.POST['p']=='submit':
            if request.POST['password']=='':
                return render(request,'login/detail.html',{
                    'user_name':user_name,
                    'cur':cur[0],
                    'edit':True,
                    'edit_err':'empty password'
                })
            if request.POST['email']=='':
                return render(request,'login/detail.html',{
                    'user_name':user_name,
                    'cur':cur[0],
                    'edit':True,
                    'edit_err':'empty email'
                })
            cur.update(password=request.POST['password'],email=request.POST['email'])
            return render(request,'login/detail.html',{
                    'user_name':user_name,
                    'cur':cur[0],
                    'err_text':'update successful!'

                })
        if request.POST['p']=='edit':
            return render(request,'login/detail.html',{
                    'user_name':user_name,
                    'cur':cur[0],
                    'edit':True
                })
        if request.POST['p']=='delete':
            if cur_name==user_name:
                return render(request,'login/detail.html',{
                    'user_name':user_name,
                    'cur':cur[0],
                    'err_text':'you cant delete yourself!'
                })
            cur.delete()
            return HttpResponseRedirect(reverse('login:results',args=(user_name,)))
    return render(request,'login/detail.html',{
        'user_name':user_name,
        'cur':cur[0]
    })
    try:
        user=User.objects.get(name=request.POST['name'])
    except (KeyError ,User.DoesNotExist):
        return render(request,'login/index.html',{
            'err_text':'name not found',
        })
    
    if user.password == request.POST['password']:
        return HttpResponseRedirect(reverse('login:results',args=(user.name,)))
        return render(request,'login/hello.html',{
        'name':user.name,
        'all':User.objects.all()
        })
        return HttpResponseRedirect(reverse('login:results',args=(user.name,)))
    else:
        return render(request,'login/index.html',{
            'err_text':'password error',
        })



def results(request,user_name):
    if request.method=='GET':
        return HttpResponse("you have no authority to this page!")
    return render(request,'login/hello.html',{
        'name':user_name,
        'all':User.objects.all()
    })
'''
def vote(request,user_name):
    return HttpResponse("vote %s." % user_name)
'''
def signup(request):
    if request.method=='GET':
        return render(request,'login/signup.html')
    if request.POST['name']=='':
        return render(request,'login/signup.html',{
            'err_text':'empty name'
        })
    if request.POST['password']=='':
        return render(request,'login/signup.html',{
            'err_text':'empty password'
        })
    if request.POST['email']=='':
        return render(request,'login/signup.html',{
            'err_text':'empty email'
        })
    if(User.objects.filter(name=request.POST['name']).count()!=0):
        return render(request,'login/signup.html',{
            'err_text':'username already used'
        })
    User(name=request.POST['name'],password=request.POST['password'],email=request.POST['email']).save()
    return render(request,'login/signup.html',{
        'err_text':'signup successful'
    }) 
    try:
        user=User.objects.get(name=request.POST['name'])
    except(KeyError,User.DoesNotExist):
        User(name=request.POST['name'],password=request.POST['password'],email=request.POST['email']).save()
        return render(request,'login/signup.html',{
            'err_text':'signup successful'
        })
    return render(request,'login/signup.html',{
            'err_text':'username already used'
        })
