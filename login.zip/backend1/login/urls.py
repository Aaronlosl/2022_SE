import imp
from django.urls import path

from . import views
app_name= 'login'
urlpatterns = [
    path('signup/',views.signup,name='signup'),
    path('',views.index,name='index'),
    path('<str:user_name>/<str:cur_name>/',views.detail,name='detail'),
    path('<str:user_name>/',views.results,name='results'),
    # path('<str:user_name>/vote/',views.vote,name='vote'),
]